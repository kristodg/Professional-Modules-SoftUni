package robots;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class ServiceTests {

    Service service;

    @Before
    public void setUp() {
        service = new Service("Test", 4);
        Robot robot = new Robot("RobotOne");
        Robot robot2 = new Robot("RobotTwo");
        Robot robot3 = new Robot("RobotThree");
        service.add(robot);
        service.add(robot2);
        service.add(robot3);
    }




    @Test
    public void testConstructor() {
        Service service = new Service("Test", 4);
        assertEquals("Test", service.getName());
        assertEquals(4, service.getCapacity());
        assertEquals(0, service.getCount());
    }

    @Test(expected = NullPointerException.class)
    public void testConstructorWithNullName() {
        Service service = new Service(null, 4);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testConstructorWithNegativeCapacity() {
        Service service = new Service("Test", -1);
    }

    @Test
    public void testGetCountShouldReturnCorrectCount() {
        assertEquals(3, service.getCount());
    }

    @Test
    public void testAddShouldAddRobot() {
        Robot robot = new Robot("RobotFour");
        service.add(robot);
        assertEquals(4, service.getCount());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddShouldThrowExceptionWhenListIsFull() {
        Robot robot = new Robot("RobotFour");
        Robot robot2 = new Robot("RobotFive");

        service.add(robot);
        service.add(robot2);
    }

    @Test
    public void testRemoveShouldRemoveRobot() {
        service.remove("RobotOne");
        assertEquals(2, service.getCount());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRemoveShouldThrowExceptionIfTheRobotDoesntExist() {
        service.remove("RobotFour");
    }

    @Test
   public void testForSaleShouldSetReadyForSaleShouldSetFalse(){
       Service service = new Service("Test", 4);
         Robot robot = new Robot("RobotOne");
         service.add(robot);
         service.forSale("RobotOne");
         assertFalse(robot.isReadyForSale());
    }

    @Test
    public void testForSaleShouldReturnTheRightRobot(){
        Service service = new Service("Test", 4);
        Robot robot = new Robot("RobotOne");
        service.add(robot);
        Robot actual = service.forSale("RobotOne");
        assertEquals(robot, actual);

    }
    @Test (expected = IllegalArgumentException.class)
    public void testForSaleShouldThrowExceptionIfRobotDoesntExist(){

        service.forSale("RobotFour");


    }

    @Test
    public void testReport(){
        String expected = "The robot RobotOne, RobotTwo, RobotThree is in the service Test!";
        String actual = service.report();
        assertEquals(expected, actual);
    }









}




